<?php
require_once(__DIR__. "/Diretor.php");
require_once(__DIR__. "/Genero.php");

class Filme
{
    private ?int $id = null;
    private ?string $titulo = null;
    private ?Diretor $diretor = null;
    private ?Genero $genero = null;
    private ?int $ano = null;
    private ?float $nota = null;


    /**
     * Get the value of id
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId(?int $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of titulo
     */
    public function getTitulo(): ?string
    {
        return $this->titulo;
    }

    /**
     * Set the value of titulo
     */
    public function setTitulo(?string $titulo): self
    {
        $this->titulo = $titulo;

        return $this;
    }

    /**
     * Get the value of diretor
     */
    public function getDiretor(): ?Diretor
    {
        return $this->diretor;
    }

    /**
     * Set the value of diretor
     */
    public function setDiretor(?Diretor $diretor): self
    {
        $this->diretor = $diretor;

        return $this;
    }

    /**
     * Get the value of genero
     */
    public function getGenero(): ?Genero
    {
        return $this->genero;
    }

    /**
     * Set the value of genero
     */
    public function setGenero(?Genero $genero): self
    {
        $this->genero = $genero;

        return $this;
    }

    /**
     * Get the value of ano
     */
    public function getAno(): ?int
    {
        return $this->ano;
    }

    /**
     * Set the value of ano
     */
    public function setAno(?int $ano): self
    {
        $this->ano = $ano;

        return $this;
    }

    /**
     * Get the value of nota
     */
    public function getNota(): ?float
    {
        return $this->nota;
    }

    /**
     * Set the value of nota
     */
    public function setNota(?float $nota): self
    {
        $this->nota = $nota;

        return $this;
    }
}