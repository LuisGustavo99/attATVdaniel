<?php
require_once(__DIR__ . "/../model/Filme.php");

class FilmeService
{
    public function validar(Filme $filme)
    {
        $erros = array();

        if (!$filme->getTitulo())
            $erros[] = "Informe o título do filme!";

        if (!$filme->getDiretor())
            $erros[] = "Informe o diretor!";

        if (!$filme->getGenero())
            $erros[] = "Informe o gênero!";

        if (!$filme->getAno())
            $erros[] = "Informe o ano de lançamento!";
        elseif ($filme->getAno() < 1888 || $filme->getAno() > date("Y") + 5)
            $erros[] = "Informe um ano de lançamento válido!";

        if ($filme->getNota() === null || $filme->getNota() < 0 || $filme->getNota() > 10)
            $erros[] = "A nota deve estar entre 0 e 10!";

        return $erros;
    }
}
