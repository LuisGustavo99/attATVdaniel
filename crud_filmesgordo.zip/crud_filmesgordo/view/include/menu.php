<?php require_once(__DIR__ . "/../../util/config.php"); ?>
<nav class="navbar navbar-expand-md navbar-dark bg-dark px-3">
    <a class="navbar-brand fw-bold" href="<?= BASE_URL ?>/index.php">🎬 CineCRUD</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navSite">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navSite">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/index.php">Início</a></li>
            <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/view/filmes/listar.php">Filmes</a></li>
            <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/view/filmes/inserir.php">Cadastrar</a></li>
        </ul>
    </div>
</nav>
