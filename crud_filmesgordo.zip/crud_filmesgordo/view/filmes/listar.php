<?php
require_once(__DIR__ . "/../../controller/FilmeController.php");
$filmes = (new FilmeController())->listar();

require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
?>

<div class="d-flex justify-content-between align-items-center mt-4">
    <h3>Catálogo de filmes</h3>
    <a href="inserir.php" class="btn btn-primary">+ Cadastrar filme</a>
</div>

<div class="table-responsive">
    <table class="table table-striped table-hover mt-3 align-middle">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Diretor</th>
                <th>Gênero</th>
                <th>Ano</th>
                <th>Nota</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($filmes as $f): ?>
                <tr>
                    <td><?= $f->getId() ?></td>
                    <td><strong><?= htmlspecialchars($f->getTitulo()) ?></strong></td>
                    <td><?= $f->getDiretor()->getNome() ?></td>
                    <td><span class="badge text-bg-secondary"><?= htmlspecialchars($f->getGenero()->getNome()) ?></span></td>
                    <td><?= $f->getAno() ?></td>
                    <td>⭐ <?= number_format($f->getNota(), 1, ",", ".") ?></td>
                    <td>
                        <a href="alterar.php?id=<?= $f->getId() ?>" class="btn btn-sm btn-outline-primary">Editar</a>
                        <a href="excluir.php?id=<?= $f->getId() ?>"
                            class="btn btn-sm btn-outline-danger"
                            onclick="return confirm('Confirma a exclusão deste filme?');">Excluir</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($filmes)): ?>
                <tr>
                    <td colspan="7" class="text-center">Nenhum filme cadastrado.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>