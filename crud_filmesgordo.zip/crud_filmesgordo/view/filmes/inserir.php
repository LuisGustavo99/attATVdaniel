<?php
require_once(__DIR__ . "/../../model/Filme.php");
require_once(__DIR__ . "/../../controller/FilmeController.php");

$msgErro = "";
$filme = null;

if (isset($_POST["titulo"])) {
    $filme = new Filme();
    $filme->setId(0);
    $filme->setTitulo(trim($_POST["titulo"]) ?: null);
    $idDiretor = trim($_POST["diretor"]) ?: null;
    $idGenero = trim($_POST["genero"]) ?: null;
    
    if($idGenero != null) {
        $genero = new Genero();
        $genero->setId($idGenero);
        $filme->setGenero($genero);
        }
        if($idDiretor != null) {
          $diretor = new Diretor();
          $diretor->setId($idDiretor);
          $filme->setDiretor($diretor);
      }
        
    $filme->setAno(is_numeric($_POST["ano"]) ? (int)$_POST["ano"] : null);
    $filme->setNota(is_numeric($_POST["nota"]) ? (float)$_POST["nota"] : null);

    $erros = (new FilmeController())->inserir($filme);
    if (empty($erros)) header("location: listar.php");
    else $msgErro = implode("<br>", $erros);
}

require_once(__DIR__ . "/form.php");
