<?php
require_once(__DIR__ . "/../../controller/FilmeController.php");

$msgErro = "";
$filmeCont = new FilmeController();

if (isset($_POST["titulo"])) {
    $filme = new Filme();
    $filme->setId((int)$_POST["id"]);
    $filme->setTitulo(trim($_POST["titulo"]) ?: null);
    $filme->setDiretor(trim($_POST["diretor"]) ?: null);

    $idGenero = trim($_POST["genero"]) ?: null;

    if($idGenero != null) {
        $genero = new Genero();
        $genero->setId($idGenero);
        $filme->setGenero($genero);
    }

    $filme->setAno(is_numeric($_POST["ano"]) ? (int)$_POST["ano"] : null);
    $filme->setNota(is_numeric($_POST["nota"]) ? (float)$_POST["nota"] : null);

    $erros = $filmeCont->alterar($filme);
    if (empty($erros)) header("location: listar.php");
    else $msgErro = implode("<br>", $erros);
} else {
    $id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;
    $filme = $filmeCont->buscarPorId($id);
    if (!$filme) {
        echo "ID do filme inválido!<br>";
        echo "<a href='listar.php'>Voltar</a>";
        exit;
    }
}

require_once(__DIR__ . "/form.php");
