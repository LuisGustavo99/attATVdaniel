<?php
require_once(__DIR__. "/../../controller/DiretorController.php");
require_once(__DIR__. "/../../controller/GeneroController.php");

//GeneroController para lhe retornar uma lista de gêneros do banco de dados
$generos = (new GeneroController())->listar();
$diretores = (new DiretorController())->listar();


require_once(__DIR__ . "/../include/header.php");
require_once(__DIR__ . "/../include/menu.php");
?>
<h3><?= $filme && $filme->getId() > 0 ? "Alterar" : "Cadastrar" ?> filme</h3>

<div class="row">
    <div class="col-md-7">
        <form action="" method="POST">
            <div class="mb-3">
                <label for="txtTitulo" class="form-label">Título:</label>
                <input type="text" id="txtTitulo" name="titulo" class="form-control"
                    placeholder="Ex.: Interestelar" maxlength="100"
                    value="<?= $filme ? $filme->getTitulo() : '' ?>">
            </div>

            <div class="mb-3">
                <label for="selDiretor" class="form-label">Diretor:</label>
                <select name="diretor" id="selDiretor" class="form-select">
                   <?php
                    $diretorAtual = $filme && $filme->getDiretor() ? $filme->getDiretor()->getId() : "";
                    ?> 
                    <option value="">---- Selecione ----</option>
                    <?php foreach ($diretores as $d): ?>
                        <option value="<?= htmlspecialchars($d->getId()) ?>" <?= $diretorAtual === $d->getId() ? "selected" : "" ?>>
                            <?= htmlspecialchars($d->getNome()) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="selGenero" class="form-label">Gênero:</label>
                <select name="genero" id="selGenero" class="form-select">
                   <?php
                    $generoAtual = $filme && $filme->getGenero() ? $filme->getGenero()->getId() : "";
                    ?> 
                    <option value="">---- Selecione ----</option>
                    <?php foreach ($generos as $g): ?>
                        <option value="<?= htmlspecialchars($g->getId()) ?>" <?= $generoAtual === $g->getId() ? "selected" : "" ?>>
                            <?= htmlspecialchars($g->getNome()) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="txtAno" class="form-label">Ano de lançamento:</label>
                    <input type="number" id="txtAno" name="ano" class="form-control"
                        min="1888" max="<?= date("Y") + 5 ?>"
                        value="<?= $filme ? $filme->getAno() : '' ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="txtNota" class="form-label">Nota (0 a 10):</label>
                    <input type="number" id="txtNota" name="nota" class="form-control" step="0.1"
                        value="<?= $filme ? $filme->getNota() : '' ?>">
                </div>
            </div>

            <input type="hidden" name="id" value="<?= $filme ? $filme->getId() : 0 ?>">

            <button type="submit" class="btn btn-success">Salvar filme</button>
            <a href="listar.php" class="btn btn-outline-secondary">Voltar</a>
        </form>
    </div>

    <div class="col-md-5">
        <?php if ($msgErro): ?>
            <div class="alert alert-danger mt-3"><?= $msgErro ?></div>
        <?php endif; ?>
    </div>
</div>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>