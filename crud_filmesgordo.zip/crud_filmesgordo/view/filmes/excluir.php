<?php
require_once(__DIR__ . "/../../controller/FilmeController.php");

if (isset($_GET["id"])) {
    $erro = (new FilmeController())->excluir((int)$_GET["id"]);
    if (!$erro) header("location: listar.php");
    else {
        echo $erro . "<br>";
        echo "<a href='listar.php'>Voltar</a>";
    }
} else {
    echo "ID do filme não informado!<br>";
    echo "<a href='listar.php'>Voltar</a>";
}
