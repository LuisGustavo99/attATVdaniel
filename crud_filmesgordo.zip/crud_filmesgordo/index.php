<?php
require_once(__DIR__ . "/util/config.php");
require_once(__DIR__ . "/view/include/header.php");
require_once(__DIR__ . "/view/include/menu.php");
?>

<div class="p-5 my-4 bg-dark text-white rounded-3 text-center">
    <h1>🎬 CineCRUD</h1>
    <p class="lead">Seu catálogo de filmes simples e organizado.</p>
    <a href="<?= BASE_URL ?>/view/filmes/listar.php" class="btn btn-light btn-lg">Ver catálogo</a>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card h-100 shadow-sm"><div class="card-body text-center">
            <h2>🎥</h2><h5 class="card-title">Cadastrar</h5>
            <p class="card-text">Adicione novos filmes ao catálogo.</p>
        </div></div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 shadow-sm"><div class="card-body text-center">
            <h2>✏️</h2><h5 class="card-title">Editar</h5>
            <p class="card-text">Atualize as informações dos filmes.</p>
        </div></div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 shadow-sm"><div class="card-body text-center">
            <h2>⭐</h2><h5 class="card-title">Avaliar</h5>
            <p class="card-text">Registre uma nota de 0 a 10 para cada filme.</p>
        </div></div>
    </div>
</div>

<?php require_once(__DIR__ . "/view/include/footer.php"); ?>