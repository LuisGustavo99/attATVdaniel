<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Diretor.php");

class DiretorDAO
{
    public function list()
    {
        $sql = "SELECT d.*
                    FROM diretores d
                    ORDER BY d.nome";
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        return $this->map($stm->fetchAll());
    }
private function map(array $dados)
    {
        $diretores = array();
        foreach ($dados as $d) {
         
            $diretor = new Diretor();
            $diretor->setId($d["id"]);
            $diretor->setNome($d["nome"]);
            $diretores[] = $diretor;
        }
        return $diretores;
    }
}