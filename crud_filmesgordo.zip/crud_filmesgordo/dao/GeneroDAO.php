<?php
require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Genero.php");

class GeneroDAO
{
    public function list()
    {
        $sql = "SELECT g.*
                    FROM generos g
                    ORDER BY g.nome";
        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();
        return $this->map($stm->fetchAll());
    }
    private function map(array $dados)
    {
        $generos = array();
        foreach ($dados as $d) {
            //Criar um objeto gênero
            $genero = new Genero();


            //Setar os atributos
            $genero->setId($d["id"]);
            $genero->setNome($d["nome"]);

            //Adicionar o objeto genero no array
            $generos[] = $genero;
        }
        return $generos;
    }
}
