<?php

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Filme.php");
require_once(__DIR__ . "/../model/Diretor.php");
require_once(__DIR__ . "/../model/Genero.php");

class FilmeDAO
{
    public function list()
    {
        $sql = "SELECT f.*,
                       g.nome AS nome_genero,
                       d.nome AS nome_diretor
                FROM filmes f
                JOIN generos g ON (g.id = f.id_genero)
                JOIN diretores d ON (d.id = f.id_diretor)
                ORDER BY f.id";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute();

        return $this->map($stm->fetchAll());
    }

    public function findById(int $id): ?Filme
    {
        $sql = "SELECT f.*,
                       g.nome AS nome_genero,
                       d.nome AS nome_diretor
                FROM filmes f
                JOIN generos g ON (g.id = f.id_genero)
                JOIN diretores d ON (d.id = f.id_diretor)
                WHERE f.id = ?";

        $conn = Connection::getConnection();
        $stm = $conn->prepare($sql);
        $stm->execute([$id]);

        $filmes = $this->map($stm->fetchAll());

        return !empty($filmes) ? $filmes[0] : null;
    }

    public function insert(Filme $filme)
    {
        try {

            $sql = "INSERT INTO filmes
                    (titulo, id_diretor, id_genero, ano, nota)
                    VALUES (:titulo, :id_diretor, :id_genero, :ano, :nota)";

            $stm = Connection::getConnection()->prepare($sql);

            $stm->execute([
                ":titulo" => $filme->getTitulo(),
                ":id_diretor" => $filme->getDiretor()->getId(),
                ":id_genero" => $filme->getGenero()->getId(),
                ":ano" => $filme->getAno(),
                ":nota" => $filme->getNota()
            ]);

            return "";

        } catch (PDOException $e) {

            $erro = "Erro ao salvar o filme. Tente novamente.";

            if (AMB_DEV) {
                $erro .= "<br>" . $e->getMessage();
            }

            return $erro;
        }
    }

    public function update(Filme $filme)
    {
        try {

            $sql = "UPDATE filmes
                    SET titulo = :titulo,
                        id_diretor = :id_diretor,
                        id_genero = :id_genero,
                        ano = :ano,
                        nota = :nota
                    WHERE id = :id";

            $stm = Connection::getConnection()->prepare($sql);

            $stm->execute([
                ":titulo" => $filme->getTitulo(),
                ":id_diretor" => $filme->getDiretor()->getId(),
                ":id_genero" => $filme->getGenero()->getId(),
                ":ano" => $filme->getAno(),
                ":nota" => $filme->getNota(),
                ":id" => $filme->getId()
            ]);

            return "";

        } catch (PDOException $e) {

            $erro = "Erro ao atualizar o filme. Tente novamente.";

            if (AMB_DEV) {
                $erro .= "<br>" . $e->getMessage();
            }

            return $erro;
        }
    }

    public function excluir(int $id)
    {
        try {

            $stm = Connection::getConnection()
                ->prepare("DELETE FROM filmes WHERE id = ?");

            $stm->execute([$id]);

            return "";

        } catch (PDOException $e) {

            $erro = "Erro ao excluir o filme. Tente novamente.";

            if (AMB_DEV) {
                $erro .= "<br>" . $e->getMessage();
            }

            return $erro;
        }
    }

    private function map(array $dados)
    {
        $filmes = array();

        foreach ($dados as $d) {

            $filme = new Filme();

            $filme->setId($d["id"]);
            $filme->setTitulo($d["titulo"]);

            // Diretor
            $diretor = new Diretor();
            $diretor->setId($d["id_diretor"]);
            $diretor->setNome($d["nome_diretor"]);

            $filme->setDiretor($diretor);

            // Gênero
            $genero = new Genero();
            $genero->setId($d["id_genero"]);
            $genero->setNome($d["nome_genero"]);

            $filme->setGenero($genero);

            $filme->setAno($d["ano"]);
            $filme->setNota((float) $d["nota"]);

            $filmes[] = $filme;
        }

        return $filmes;
    }
}