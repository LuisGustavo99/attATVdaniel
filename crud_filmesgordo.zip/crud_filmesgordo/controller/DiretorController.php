<?php

require_once(__DIR__ . "/../dao/DiretorDAO.php");

class DiretorController{

    private DiretorDAO $diretorDAO;
    

    public function __construct()
    {
        $this->diretorDAO = new DiretorDAO();
    }

    public function listar()
    {
        return $this->diretorDAO->list();
    }   
}