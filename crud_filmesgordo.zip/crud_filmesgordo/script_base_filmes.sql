CREATE DATABASE IF NOT EXISTS dbFilmes;
USE dbFilmes;



CREATE TABLE diretores (
    id INT AUTO_INCREMENT,
    nome VARCHAR(70) NOT NULL,
    PRIMARY KEY (id)
);
INSERT INTO diretores (nome) VALUES('Christopher Nolan');
INSERT INTO diretores (nome) VALUES('James Cameron');
INSERT INTO diretores (nome) VALUES('Steven Spielberg');
INSERT INTO diretores (nome) VALUES('Peter Jackson');
INSERT INTO diretores (nome) VALUES('Robert Zemeckis');
INSERT INTO diretores (nome) VALUES('Lana Wachowski');
INSERT INTO diretores (nome) VALUES('Lilly Wachowski ');
INSERT INTO diretores (nome) VALUES('Roger Allers');
INSERT INTO diretores (nome) VALUES('Rob Minkoff');
INSERT INTO diretores (nome) VALUES('Quentin Tarantino');

CREATE TABLE generos (
    id INT AUTO_INCREMENT,
    nome VARCHAR(70) NOT NULL,
    PRIMARY KEY (id)
);

INSERT INTO generos (nome) VALUES ('Ação');
INSERT INTO generos (nome) VALUES ('Aventura');
INSERT INTO generos (nome) VALUES ('Comédia');
INSERT INTO generos (nome) VALUES ('Drama');
INSERT INTO generos (nome) VALUES ('Ficção científica');
INSERT INTO generos (nome) VALUES ('Terror');
INSERT INTO generos (nome) VALUES ('Animação');
INSERT INTO generos (nome) VALUES ('Fantasia');
INSERT INTO generos (nome) VALUES ('Suspense');
INSERT INTO generos (nome) VALUES ('Romance');

CREATE TABLE filmes (
    id INT AUTO_INCREMENT NOT NULL,
    titulo VARCHAR(100) NOT NULL,
    id_diretor INTEGER NOT NULL,
    id_genero INTEGER NOT NULL,
    ano INT NOT NULL,
    nota DECIMAL(3,1) NOT NULL,
    CONSTRAINT pk_filmes PRIMARY KEY (id)
);
ALTER TABLE filmes ADD CONSTRAINT fk_genero FOREIGN KEY (id_genero) REFERENCES generos (id);
ALTER TABLE filmes ADD CONSTRAINT fk_diretor FOREIGN KEY (id_diretor) REFERENCES diretores (id);
INSERT INTO filmes (titulo, id_diretor, id_genero, ano, nota) VALUES
('Interestelar', (SELECT d.id FROM diretores d WHERE d.nome = "Christopher Nolan") , (SELECT g.id FROM generos g WHERE g.nome = 'Ficção científica'), 2014, 9.0);


